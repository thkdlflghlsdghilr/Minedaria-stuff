﻿using System;
using System.Windows.Forms;
using System.Net;
using Newtonsoft.Json.Linq;

namespace minedariasunny
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			using (WebClient wc = new System.Net.WebClient())
			{
				var json = wc.DownloadString("https://world.minedaria.com/up/world/world/");
				var details = JObject.Parse(json);
				var rain = (string)details["hasStorm"];
				if (rain == "False")
				{
					label2.Text = "No";
				}
				else
				{
					label2.Text = "Yes";
				}
			}
		}
	}
}
